Stronger Ball and Socket Links by BManx2000 on Thingiverse: https://www.thingiverse.com/thing:2539262

Summary:
When I tried printing the original ball and socket links, the socket pieces would snap off when assembled. So I made this stronger version which prints on its side. The friction fit is nice and tight. I did have one piece split lengthwise when assembled though, so this still isn't perfect.I used ASA for my print, so I'm not sure if this will work with the more rigid PLA.